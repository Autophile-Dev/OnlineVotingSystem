<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin-home.css">
    <link rel="stylesheet" href="css/candidates.css">
    <title>Add NA Candidate</title>
</head>
<body>
    <?php include('navbar.php'); ?>
    <script src="adminjs/adminjs.js"></script>
    <div class="info">
        <h1>For National Assembly</h1>
    </div>
    <div class="container">
        <?php
            include('../db/conn.php');
            $sql = mysqli_query($con,"SELECT `box` FROM parties WHERE `assembly`='national'");
            $array = array();
            while($row = mysqli_fetch_array($sql)){
                $i = 0;
                array_push($array,$row[$i]);
                $i++;
            }
            for ($i=1; $i<=8 ; $i++) { 
                if(in_array($i, $array)){
                    echo '
                            <div class="box box'.$i.'">
                                <h3>For Box-'.$i.'</h3>
                                <div class="buttons">
                                    <a href="add.php?assembly=national&b='.$i.'"><button disabled class="add">Record Found</button></a>
                                    <a href="edit.php?assembly=national&b='.$i.'""><button class="edit">Edit Record</button></a>
                                </div>
                            </div>
                    ';
                }else{
                    echo '
                            <div class="box box'.$i.'">
                                <h3>For Box-'.$i.'</h3>
                                <div class="buttons">
                                    <a href="add.php?assembly=national&b='.$i.'"><button class="add">Add Record</button></a>
                                    <a href="edit.php?assembly=national&b='.$i.'""><button class="edit">Edit Record</button></a>
                                </div>
                            </div>
                    ';
                }
            }
        ?>
    </div>
    <!-- <div class="container">
        <div class="box box1">
            <h3>For Box-1</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=1"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box2">
            <h3>For Box-2</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=2"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box3">
            <h3>For Box-3</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=3"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box4">
            <h3>For Box-4</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=4"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box5">
            <h3>For Box-5</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=5"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box6">
            <h3>For Box-6</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=6"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box7">
            <h3>For Box-7</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=7"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
        <div class="box box8">
            <h3>For Box-8</h3>
            <div class="buttons">
                <a href="add.html?assembly=national&b=8"><button class="add">Add Record</button></a>
                <a href="edit.html"><button class="edit">Edit Record</button></a>
            </div>
        </div>
    </div> -->
    <div class="nabtn">
        <a href="pp-candidate.php"><button class="btn">Next</button></a>
    </div>
</body>
</html>