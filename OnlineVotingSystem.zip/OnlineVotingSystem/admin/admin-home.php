<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/admin-home.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet"> -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OVS</title>
</head>
<body>
    <?php include('navbar.php'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 news-section p-0">
                <div class="news-item">
                    <div class="news-post">
                        <span class="badge badge-success mb-3 mb-3">
                            <a href="#" rel="tag">Latest</a>
                        </span>
                            <h1 class="news-title">
                                <a href="https://www.thenews.com.pk/latest/928587-massive-amendments-to-bring-revolution-in-criminal-justice-system-pm-imran-khan">
                                    Massive amendments to bring revolution in criminal justice system': PM Imran Khan
                                </a>
                            </h1>
        </div>
            <img src="news/imrankhan.jpg" alt="">
        </div>
        <div class="news-item">
            <div class="news-post">
                <span class="badge badge-success mb-3 mb-3">
                    <a href="#" rel="tag">Latest</a>
                </span>
                    <h1 class="news-title">
                        <a href="#">
                            ECP not sure about use of EVMs in next polls
                        </a>
                    </h1>
            </div>
        <img src="news/ECP.png" alt="">
        </div>
        <div class="news-item">
            <div class="news-post">
                <span class="badge badge-success mb-3">
                    <a href="#" rel="tag">Latest</a>
                </span>
            <h1 class="news-title">
                <a href="https://www.dawn.com/news/1616074/pdm-splits-as-five-parties-to-form-new-bloc">
                    PDM splits as five parties to form new bloc
                </a>
            </h1>
        </div>
        <img src="news/pdm.png" alt="">
        </div>
        <div class="news-item">
        <div class="news-post">
        <span class="badge badge-success mb-3">
        <a href="#" rel="tag">Latest</a>
        </span>
        <h1 class="news-title">
        </a>
        <a href="https://www.dawn.com/news/1644463/dont-worry-everything-will-be-okay-isi-chief-during-kabul-visit">
            'Don't worry, everything will be okay': ISI chief during Kabul visit
        </h1>
        </div>
            <img src="news/ISI.jpg" alt="">
        </div>
        </div>
        <div class="col-md-6 news-section p-0">
            <div class="news-item">
                <div class="news-post">
                    <span class="badge badge-success mb-3">
                        <a href="#" rel="tag">Latest</a>
                    </span>
                    <h1 class="news-title">
                        <a href="https://firstsportz.com/cricket-remainder-of-pakistan-super-league-2021-set-to-be-played-in-january-2022/">
                            Remainder of Pakistan Super League 2021 set to be played in January 2022
                        </a>
                    </h1>
            </div>
                <img src="news/psl.jpg" alt="">
        </div>
        <div class="news-item">
            <div class="news-post">
                <span class="badge badge-info mb-3">
                    <a href="#" rel="tag">Latest</a>
                </span>
                <h1 class="news-title">
                <a href="https://www.bolnews.com/technology/2022/01/iphone-13-prices-in-pakistan-after-increased-taxes/">
                    iPhone 13 Prices in Pakistan After Increased Taxes
                </a>
                </h1>
        </div>
            <img src="news/iphone.jpg" alt="">
        </div>
        <div class="news-item">
            <div class="news-post">
                <span class="badge badge-warning mb-3">
                    <a href="#" rel="tag">Latest</a>
                </span>
                    <h1 class="news-title">
                    <a href="https://www.defencetalk.com/pakistan-wins-first-jet-order-at-paris-air-show-spokesman-64501/">
                        Pakistan wins first jet order at Paris Air Show: spokesman
                    </a>
                    </h1>
                </span>
        </div>
            <img src="news/jf17.jpg" alt="">
        </div>
        <div class="news-item">
            <div class="news-post">
                <span class="badge badge-secondary mb-3">
                    <a href="#" rel="tag">Latest</a>
                </span>
            <h1 class="news-title">
            <a href="https://propakistani.pk/2021/10/21/minister-of-state-shares-a-big-news-on-cryptocurrency-ban-in-pakistan/">
                Minister of State Shares a Big News on Cryptocurrency Ban in Pakistan
            </a>
            </h1>
        </span>
        </div>
            <img src="news/crypto-Pakistan-PP.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- End of News Section -->
    <script
        src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous">
    </script>
    <script src="js/home.js"></script>
</body>
</html>