<?php

include("../../db/conn.php");
    
    $valid['success'] = array('success' => false, 'messages' => array());

    if($_SERVER['REQUEST_METHOD'] == "POST"){
        
        $candName = mysqli_real_escape_string($con, $_POST['candName']);
        $partyName = mysqli_real_escape_string($con, $_POST['partyName']);
        $assembly = mysqli_real_escape_string($con, $_POST['assembly']);
        $box = mysqli_real_escape_string($con, $_POST['box']);

        // File...
        $files = $_FILES['fileToUpload'];
        $filename = $files['name'];
        $fileerror = $files['error'];
        $filetmp = $files['tmp_name'];

        $fileext = explode('.',$filename);
        $filecheck = strtolower(end($fileext));
        $fileextstored = array('png', 'jpg', 'jpeg');

        if(in_array($filecheck,$fileextstored)){
            $destinationfile = '../../media/parties/'.$filename;
            $destinationForDatabase = $filename;
            move_uploaded_file($filetmp,$destinationfile);
        }
        if(!isset($destinationForDatabase)){
            $valid['success'] = false;
            $valid['messages'] = "Image file have some error!";
            $valid['class'] = "bg-danger";
            $valid['title'] = "Error";
        }else{
            $sql = "INSERT INTO parties (`candName`,`partyName`,`assembly`,`box`,`image`) VALUES ('$candName','$partyName','$assembly','$box','$destinationForDatabase')";
        }

        mysqli_query($con, $sql);

        $valid['success'] = true;
        $valid['messages'] = "Your Data Inserted Successfully!";
        $valid['class'] = "bg-success";
        $valid['title'] = "Done";

    }else{
        $valid['success'] = false;
        $valid['messages'] = "Your Data Insertion Have Some Error!";
        $valid['class'] = "bg-danger";
        $valid['title'] = "Error";
    }

        
    $con->close();
    echo json_encode($valid);
    // echo $valid;

?>