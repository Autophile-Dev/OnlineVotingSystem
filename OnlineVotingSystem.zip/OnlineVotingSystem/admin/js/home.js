//<<=Toggle=>>
$(document).ready(function(){
    $('.menu-toggle').click(function(){
        $('.menu-toggle').toggleClass('active')
        $('nav').toggleClass('active')
    })
})
//<<=Clock=>>
function Time()
//Call the Date class 
{   let date =  new Date();
    //Call Hour functions
    let hour =  date.getHours();
    //Call minutes functions
    let minute =  date.getMinutes();
    //Call seconds functions
    let seconds =  date.getSeconds();
    let s = "AM";
    if(hour === 0)
    {
        hour = 12;
    }
    if(hour > 12)
    {
        hour = hour - 12;
        s = "PM";
    }
    hour = (hour < 10) ? "0" + hour : hour;
    minute = (minute < 10) ? "0" + minute : minute;
    seconds = (seconds < 10) ? "0" + seconds : seconds;
    let time = hour + ":" + minute + ":" + seconds + " " + s;
    document.getElementById("clock").innerText = time; let T = setTimeout(function(){
    Time()}, 1000); 
}
Time();