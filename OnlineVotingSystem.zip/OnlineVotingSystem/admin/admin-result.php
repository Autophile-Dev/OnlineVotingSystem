<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin-home.css">
    <title>Result</title>
</head>
<body>
    <style>
        table tr th 
        {
            color: #069370;
        }
        td{
            color: black;
        }
    </style>
    <?php include('navbar.php'); ?>
    <script
        src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous">
    </script>
    <script src="js/home.js"></script>
    <div class="container">
        <div class="userinfo">
            <!-- Data Of Result Should be displayed Here -->
            <table border  = "1px" style="text-align:center">
                <thead>
                    <tr>
                        <th>Sr.No#</th>
                        <th>Candidate Name</th>
                        <th>Party Name</th>
                        <th>Electoral Sign</th><!--Uploaded image-->
                        <th>Total Votes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        include('../db/conn.php');
                        $sql = mysqli_query($con,"SELECT votes.partyId, COUNT(votes.id) AS totalVotes, parties.candName, parties.partyName, parties.image FROM votes LEFT JOIN parties ON parties.Id=votes.partyId GROUP BY votes.partyId;");
                        while($row = mysqli_fetch_array($sql)){
                            $i = 1;
                            echo '<tr>
                                    <td>'.$row['partyId'].'</td>
                                    <td>'.$row['candName'].'</td>
                                    <td>'.$row['partyName'].'</td>
                                    <td><img src="../media/parties/'.$row['image'].'" width="50"></td>
                                    <td>'.$row['totalVotes'].'</td>
                                </tr>';
                            $i++;
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>