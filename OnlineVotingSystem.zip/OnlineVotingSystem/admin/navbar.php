<?php

session_start();
if(!isset($_SESSION["cnic"])){
    header("location: ../login.php");
}else{
    $cnic = $_SESSION['cnic'];
}

?>
<header>
        <a href="#" class="logo">OVS</a>
        <div class="menu-toggle"></div>
        <link rel="stylesheet" href="css/admin-home.css">
        <link rel="stylesheet" href="css/candidate.css">
        <nav>
            <ul>
                <li><a href="admin-home.php">Home</a></li>
                <li><a href="candidates.php">Add Candidates</a></li>
                <li><a href="admin-profile.php">Profile</a></li>
                <li><a href="admin-logout.php">Log out</a></li>
            </ul>
        </nav>
        <div class="clearfix"></div>
        <div id="clock" onload="Time()"></div>
    </header>