<?php
    include('../db/conn.php');
    $assembly = $_GET['assembly'];
    $box = $_GET['b'];
    $sql = mysqli_query($con,"SELECT * FROM parties WHERE `assembly`='$assembly' AND `box`='$box'");
    $result = mysqli_fetch_assoc($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin-home.css">
    <link rel="stylesheet" href="css/candidates.css">
    <title>Edit Record</title>
</head>
<body>
    <header>
        <center><a href="#" class="logo">OVS</a></center>
        <div class="menu-toggle"></div>
        <div class="clearfix"></div>
    </header>
    <div class="center">
        <div class="add-edit-record">
            <div class="header">Edit Record</div>
            <form id="myForm" action="includes/update_parties.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="assembly" value="<?php echo $assembly; ?>">
                <input type="hidden" name="box" value="<?php echo $box; ?>">
                <p>Enter Candidate Name: </p><input type="text" required placeholder="Candidate Name" name="candName" value="<?php echo $result['candName']; ?>"class="cd-name">
                <p>Enter Party Name: </p><input type="text" required placeholder="Party Name" name="partyName" value="<?php echo $result['partyName']; ?>"class="p-name">
                <p>Select Party Logo: </p><input type="file" name="fileToUpload" required class="p-img">
                <br><br>
                <center><button class="edit">Edit Record</button></center>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="js/forms.js"></script>
</body>
</html>