<?php

session_start();
if(!isset($_SESSION["cnic"])){
    header("location: login.php");
}else{
    $cnic = $_SESSION['cnic'];
}

?>
<header>
        <a href="#" class="logo">OVS</a>
        <div class="menu-toggle"></div>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="parties.php">Parties</a></li>
                <li><a href="MNAvotes.php">Vote</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="logout.php">Log out</a></li>
            </ul>
        </nav>
        <div class="clearfix"></div>
        <div id="clock" onload="Time()"></div>
    </header>