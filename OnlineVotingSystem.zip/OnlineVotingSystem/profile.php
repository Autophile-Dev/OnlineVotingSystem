
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="all.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voter Profile</title>
</head>
<body>
    <?php 
        include('navbar.php');
        include('db/conn.php');
        $sql = mysqli_query($con,"SELECT * FROM users WHERE `cnic`='$cnic'");
        $profile = mysqli_fetch_array($sql);
        if($profile['status'] == 'Voted'){
            $color = 'green';
        }else{
            $color = 'red';
        }
    ?>
    <div class="container">
        <div class="userinfo">
            <p><strong>Name: </strong> <?php echo $profile['fname'].' '.$profile['lname']; ?></p>
            <p><strong>CNIC: </strong> <?php echo $profile['cnic']; ?></p>
            <p><strong>Address: </strong> <?php echo $profile['address']; ?></p>
            <p><strong>Role: </strong> <?php echo $profile['role']; ?></p>
            <p><strong>Status: </strong><span style="color:<?php echo $color ?> !important"><?php echo $profile['status']; ?></span></p> <!--If voted then text color will be green If non voted then text color will be red-->
            <br>
            <div class="result-election">
                <p><a href="voter-result.php"><strong>Click Here </strong></a> and check the result</p>
            </div>
        </div>
        
    </div>
    <script
        src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous">
    </script>
    <script src="js/home.js"></script>
</body>
</html>