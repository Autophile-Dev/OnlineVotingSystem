<?php
session_start();
include("../db/conn.php");
    
    $valid['success'] = array('success' => false, 'messages' => array());

        $cnic = $_SESSION['cnic'];
        $party = $_GET['party'];
        $assembly = $_GET['assembly'];

        $check = "SELECT * FROM `votes` WHERE `userCNIC`='$cnic' AND `assembly`='$assembly'";
        $result = mysqli_query($con, $check);
        $num = mysqli_num_rows($result);

        if($num == 1){
            header("Location: ../MNAvotes.php?status=Your Vote Already Exist!");
        }else{
            $sql = "INSERT INTO votes (`userCNIC`,`partyId`,`assembly`) VALUES ('$cnic','$party','$assembly')";
            mysqli_query($con, $sql);
            mysqli_query($con, "UPDATE `users` SET `status`='Voted'");

            header("Location: ../MNAvotes.php?status=Your Vote Added Successfully!");
        }


        
    $con->close();
    echo json_encode($valid);
    // echo $valid;

?>