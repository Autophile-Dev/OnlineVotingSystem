<?php

session_start();
include("../db/conn.php");
    

    if($_SERVER['REQUEST_METHOD'] == "POST"){
        
        
        $cnic = mysqli_real_escape_string($con, $_POST['cnic']);
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $role = mysqli_real_escape_string($con, $_POST['role']);

        
        $check = "SELECT * FROM `users` WHERE `cnic`='$cnic' AND `password`='$password' AND `role`='$role'";
        $result = mysqli_query($con, $check);
        $num = mysqli_num_rows($result);

        if($num == 1){
            $_SESSION['cnic'] = $cnic;
            if($role=='admin'){
                header("Location: ../admin/admin-home.php");
            }else{
                header("Location: ../home.php");
            }
        }else{
            header("Location: ../login.php?error=1");

        }


}

?>