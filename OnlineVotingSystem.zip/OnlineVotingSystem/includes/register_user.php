<?php

include("../db/conn.php");
    
    $valid['success'] = array('success' => false, 'messages' => array());

    if($_SERVER['REQUEST_METHOD'] == "POST"){
        
        
        $fname = mysqli_real_escape_string($con, $_POST['fname']);
        $lname = mysqli_real_escape_string($con, $_POST['lname']);
        $cnic = mysqli_real_escape_string($con, $_POST['cnic']);
        $address = mysqli_real_escape_string($con, $_POST['address']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $role = mysqli_real_escape_string($con, $_POST['role']);

        // Checking emails recurring...
        $check = "SELECT * FROM `users` WHERE `cnic`='$cnic' AND `role`='$role'";
        $result = mysqli_query($con, $check);
        $num = mysqli_num_rows($result);

        if($num == 1){
            $valid['success'] = false;
            $valid['messages'] = "The CNIC Number Already Exist!";
            $valid['class'] = "bg-danger";
            $valid['title'] = "Error";
        }else{
            $sql = "INSERT INTO users (`fname`,`lname`,`cnic`,`address`,`phone`,`email`,`password`,`role`) VALUES ('$fname','$lname','$cnic','$address','$phone','$email','$password','$role')";
            mysqli_query($con, $sql);

            $valid['success'] = true;
            $valid['messages'] = "Your Data Inserted Successfully!";
            $valid['class'] = "bg-success";
            $valid['title'] = "Done";
        }


    }else{
        $valid['success'] = false;
        $valid['messages'] = "Your Data Insertion Have Some Error!";
        $valid['class'] = "bg-danger";
        $valid['title'] = "Error";
    }

        
    $con->close();
    echo json_encode($valid);
    // echo $valid;

?>