<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="parties.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OVS</title>
</head>
<body>
    <?php include('navbar.php') ?>
    <!-- News Section -->
    <div class="container">
        <div class="box box1">
            <img src="party/PTI.png" alt="">
        </div>
        <div class="box box2">
            <h1>Pakistan Tehreek-e-Insaaf (PTI)</h1>
            <p><strong>Party Chairman: </strong> Imran Khan</p>
            <p><strong>Election Symbol: </strong> Bat</p>
        </div>
        <div class="box box3">
            <img src="party/PML(N).png" alt="">
        </div>
        <div class="box box4">
            <h1>Pakistan Muslim League (PMLN)</h1>
            <p><strong>Party Chairman: </strong> Nawaz Sharif</p>
            <p><strong>Election Symbol: </strong> Tiger</p>
        </div>
        <div class="box box5">
            <img src="party/PPP.png" alt="">
        </div>
        <div class="box box6">
            <h1>Pakistan Peoples Party (PPP)</h1>
            <p><strong>Party Chairman: </strong> Bilawal Bhutto Zardari</p>
            <p><strong>Election Symbol: </strong> Arrow</p>
        </div>
        <div class="box box7">
            <img src="party/BPP.png" alt="">
        </div>
        <div class="box box8">
            <h1>Barabri Party Pakistan BPP (Ind)</h1>
            <p><strong>Party Chairman: </strong> Jawad Ahmad</p>
            <p><strong>Election Symbol: </strong> Pen</p>
        </div>
        <div class="box box9">
            <img src="party/MQMP.png" alt="">
        </div>
        <div class="box box10">
            <h1>Mohajir Qoumi Movement Pakistan MQMP-H (Ind)</h1>
            <p><strong>Party Chairman: </strong> Afaq Ahmad</p>
            <p><strong>Election Symbol: </strong> Candle</p>
        </div>
        <div class="box box11">
            <img src="party/MMA.png" alt="">
        </div>
        <div class="box box12">
            <h1>Mutahida Majlis-e-Amal (MMA)</h1>
            <p><strong>Party Chairman: </strong> Fazal-ur-Rehman</p>
            <p><strong>Election Symbol: </strong> Balance</p>
        </div>
        <div class="box box13">
            <img src="party/Tehreek-e-Labbaik_flag.png" alt="">
        </div>
        <div class="box box14">
            <h1>Tehreek-e-Labaiek Pakistan (TLP)</h1>
            <p><strong>Ameer: </strong> Saad Hussain Rizvi</p>
            <p><strong>Election Symbol: </strong> Crane</p>
        </div>
        <div class="box box15">
            <img src="party/PSP.png" alt="">
        </div>
        <div class="box box16">
            <h1>Pak Sar Zameen Party (PSP)</h1>
            <p><strong>Party Chairman: </strong> Syed Mustafa Kamal</p>
            <p><strong>Election Symbol: </strong> Dolphin</p>
        </div>
        
    </div>
    <script
        src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous">
    </script>
    <script src="js/home.js"></script>
</body>
</html>