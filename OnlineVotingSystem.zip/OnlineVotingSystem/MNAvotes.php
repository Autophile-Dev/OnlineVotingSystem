<?php
    if(isset($_GET['status'])){
        echo '<script>alert("'.$_GET['status'].'")</script>';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="vote.css">
    <link rel="stylesheet" href="all.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <title>Votes</title>
</head>
<body>

    <?php 
        include('navbar.php');
        include('db/conn.php');
        $sql = mysqli_query($con,"SELECT COUNT(*) AS stations FROM parties WHERE `assembly`='national'");
        $result = mysqli_fetch_assoc($sql);
    ?>
    <div class="info">
        <h1>NA-130</h1>
        <h3>Polling Station: <?php echo $result['stations']; ?></h3>
    </div>
    <script
        src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous">
    </script>
    <script src="js/home.js"></script>
    <div class="container">
        <?php
            $sql = mysqli_query($con,"SELECT * FROM parties WHERE `assembly`='national'");
            while($row = mysqli_fetch_array($sql)){
                $i = $row['box'];
                $partyId = $row['id'];
                echo '
                        <div class="box box'.$i.'">
                            <div class="sign">
                                <img src="media/parties/'.$row['image'].'" alt="">
                            </div>
                                <p><strong>Party Name: </strong>'.$row['partyName'].'</p>
                                <p><strong>Candidate Name: </strong>'.$row['candName'].'</p>
                            <div class="vote">
                            <a href="includes/voteconfirmation.php?party='.$partyId.'&assembly=national"><button>Vote</button></a>
                            </div>
                        </div>
                ';
            }
        ?>
    </div>
    <!-- <div class="container">
        <div class="box box1">
            <div class="sign">
                <img src="logo/cricket-bat.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Pakistan Tehreek-e-Insaf</p>
                <p><strong>Candidate Name: </strong>Shafqat Mehmood</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        
        <div class="box box2">
            <div class="sign">
                <img src="logo/tiger.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Pakistan Muslim League (N)</p>
                <p><strong>Candidate Name: </strong>Khawaja Ahmad Hassaan</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        <div class="box box3">
            <div class="sign">
                <img src="logo/arrow.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Pakistan Peoples Party</p>
                <p><strong>Candidate Name: </strong>M.Mumtaz Khalid</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        <div class="box box4">
            <div class="sign">
                <img src="logo/pen.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Barabri Party Pakistan <strong>(Ind)</strong></p>
                <p><strong>Candidate Name: </strong>Amjad Masood</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        <div class="box box5">
            <div class="sign">
                <img src="logo/candle.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Mohajir Qoumi Movement <strong>(Ind)</strong></p>
                <p><strong>Candidate Name: </strong>Saad Bin Hassan</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        <div class="box box6">
            <div class="sign">
                <img src="logo/dolphin.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Pak Sar Zamee Party</p>
                <p><strong>Candidate Name: </strong>M. Yameen Awan</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        <div class="box box7">
            <div class="sign">
                <img src="logo/balance.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Mutahida Majlis-e-Amal</p>
                <p><strong>Candidate Name: </strong>Liaqat Baloch</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
        <div class="box box8">
            <div class="sign">
                <img src="logo/crane.png" alt="">
            </div>
                <p><strong>Party Name: </strong>Tehreek-e-Labaiek Pakistan</p>
                <p><strong>Candidate Name: </strong>Hafeez-ur-Rehman</p>
            <div class="vote">
                <button>Vote</button>
            </div>
        </div>
    </div> -->
    <footer>
        <div class="forbtns">
        <a href="MPAvotes.php"><button type="button" class="right">Next</button></a>
    </div>
    </footer>
</body>
</html>