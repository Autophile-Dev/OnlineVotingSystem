<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Registaration</title>
</head>
<body>
    <div class="center">
        <div class="registeration">
            <div class="header">Registeration</div>
            <br>
            <form id="myForm" action="includes/register_user.php" method="post">
                <input required class="first" type="text" placeholder="First Name" name="fname">
                <input required class="last" type="text" placeholder="Last Name" name="lname">
                <input required class="cnic" type="number" placeholder="CNIC No" name="cnic">
                <input required class="address" type="text" placeholder="Address" name="address">
                <input required class="phone" type="number" placeholder="Phone No" name="phone">
                <input required class="mail" type="email" placeholder="Email" name="email">
                <input required class="pass" type="password" placeholder="Password" name="password">
                <input required class="cpass" type="password" placeholder="Confirm Password">
                <select name="role" id="role" name="role">
                    <option value="select">Select the role</option>
                    <option value="voter">Voter</option>
                    <option value="admin">Admin</option>
                </select>
                <input class="otp" type="text" placeholder="O-T-P">
                <button id="send">Send SMS</button>
                <input type="submit" value="Register">
                <p>Already have an account?<a href="login.php"> Login here</a></p><br>
            </form>
        </div>
    </div> 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="admin/js/forms.js"></script> 
</body>
</html>