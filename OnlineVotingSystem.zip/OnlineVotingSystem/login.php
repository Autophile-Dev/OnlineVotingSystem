<?php
    if(isset($_GET['error'])){
        echo '<script>alert("Login Failed!")</script>';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Log in</title>
</head>
<body>
    <div class="center">
        <div class="log-in">
            <div class="header">Log in</div>
            <form id="myForm" action="includes/login_user.php" method="post">
                <input required class="cnic" type="number" placeholder="CNIC No" name="cnic">
                <input required class="pass" type="password" placeholder="Password" name="password">
                <select name="role" id="role" name="role">
                    <option value="select">Select the role</option>
                    <option value="voter">Voter</option>
                    <option value="admin">Admin</option>
                </select>
                <input class="otp" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="\d{6}" placeholder="O-T-P">
                <button id="send">Send SMS</button>
                <input type="submit" value="Log in"> 
                <p>Didn't have an account?<a href="registration.php"> Register here</a></p><br>
            </form>
        </div>
    </div>
</body>
</html>
